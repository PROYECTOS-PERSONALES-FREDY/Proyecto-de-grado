#include "TelnetPrint.h"

NetServer TelnetPrint(23);
