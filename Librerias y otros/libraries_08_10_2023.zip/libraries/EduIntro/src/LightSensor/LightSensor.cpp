#include "LightSensor.h"
#include "EduIntro.h"

LightSensor::LightSensor(uint8_t _pin) : AnalogInput(_pin){}
